> 存放作業1-5檔案紀錄

### 講解重點

- 以messy資料集示範資料清理及描述統計函式
- 以Zhang et al. 2014 Study 3.csv 示範資料清理及六種資料視覺化
- 以James Holmes_Expt 2_DATA.csv 示範一因子獨立樣本ANOVA之分析及報告
- 以Zhang et al. 2014 Study 3.csv 示範二因子獨立樣本ANOVA之分析及報告
- 以STARS survey資料集示範簡單迴歸分析
- 以Przybylski & Weinstein (2017)資料集示範多元迴歸分析

### 作業

- 從ch 14~17挑選一個研究資料做為本段作業
- 設計研究報告Rmd範本，讓學生完成三個資料集的分析報告。
- 每份研究的分析報告要包含：效果量估計與考驗力90%的最小樣本數評估。