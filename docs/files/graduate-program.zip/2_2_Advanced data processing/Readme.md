> 存放作業2-2檔案紀錄

### 講解重點

- 整合已錄製的影片系列：https://youtube.com/playlist?list=PLSxoRcsvTAqBwSuTKEE7cOU0cSAm42gtI
- 挑選v1單元3~單元6影片
- 示範曾在1-2介紹，以及另外六種資料整頓函式

### 作業

- 由學生提供資料，自建Rmd演練v2單元3~單元7之清理整頓技巧