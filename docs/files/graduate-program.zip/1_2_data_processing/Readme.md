> 存放作業1-2檔案紀錄

### 講解重點

- 介紹tidyverse套件包
- 介紹資料集：babynames,Witt et al.(2018), AQ資料集, Woodworth et al. (2018)
- 以babynames資料集示範六種整頓資料函式
- 介紹示範管道運算子
- 以Witt et al.(2018)資料集示範六種整頓資料函式與描述統計
- 以Witt et al.(2018)資料集示範運用管道運算子處理分組及未分組資料
- 以AQ資料集說明長表單及寬表單
- 以AQ資料集示範長表單到寬表單相互轉換
- 以AQ資料集示範資料合併及計算
- 以Woodworth et al. (2018) 資料集示範ggplot視覺化函式

### 作業

- 設計Rmd集合Ch 4,5,6,7測驗題，讓學生結合可正確回答的R code
