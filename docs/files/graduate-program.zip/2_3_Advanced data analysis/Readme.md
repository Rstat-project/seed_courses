> 存放作業2-3檔案紀錄

### 講解重點

- 整合已錄製的影片系列：https://youtube.com/playlist?list=PLSxoRcsvTAqBwSuTKEE7cOU0cSAm42gtI
- 挑選v1單元8~單元10影片

### 作業

- 由學生提供主題，演練建立線性模型，製造模擬資料及建立分析程序