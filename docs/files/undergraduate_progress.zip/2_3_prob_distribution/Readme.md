> 存放作業2-3檔案紀錄

### 講解重點

- 複習1.4學過的機率分佈
- 間斷尺度資料與二項機率分佈
- 連續尺度資料與常態機率分佈

### 作業

- 依照PsyteachR ch4指引，編輯GUID_Ch4_PracticeSkills_Probabilities.Rmd