> 存放作業2-6檔案紀錄

### 講解重點

- 引用 Miller and Haden (2013) Ch 10, 11 ，以GLM介紹相關與迴歸
- 視覺化相關分析https://rpsychologist.com/correlation/
- 運用[Anscombe's quartet]示範繪製散佈圖及迴歸線
- 介紹簡單迴歸演練資料: STARS survey (Cruise, Cash, & Bolton, 1985)
- 介紹多元迴歸演練資料: Goldilocks Hypothesis (Przybylski & Weinstein,  2017)

### 作業

- 挑選ch 9,10,11至少一個單元，完成這部份業
- 依照PsyteachR ch9指引，編輯GUID_L2_Ch9_PracticeSkills.Rmd
- 依照PsyteachR ch10指引，完成STARS survey迴歸分析
- 依照PsyteachR ch11指引，完成Goldilocks Hypothesis迴歸分析
