> 存放作業1-3檔案紀錄

### 講解重點

- 介紹AQ資料集
- 解說長表單與寬表單
- 介紹示範join系列函式
  - dplyr 秘記速查表：https://raw.githubusercontent.com/rstudio/cheatsheets/main/data-transformation.pdf
- 介紹示範管道運算子

### 作業

- 使用管道運算子連結AQ資料集處理工作