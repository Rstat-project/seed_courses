> 存放作業1-2檔案紀錄

### 講解重點

- 介紹tidyverse套件包
- 介紹Woodworth et al. (2018)資料集/ babynames資料集
- 匯入及預覽data
- 以babynames 示範dplyr 資料整頓函式
  - 功能速查表：https://www.rstudio.com/wp-content/uploads/2015/02/data-wrangling-cheatsheet.pdf
- 以Woodworth et al. (2018) data set示範資料視覺化

### 作業

- 整頓Woodworth et al. (2018)資料集
- 指定非電子書變項演練視覺化

