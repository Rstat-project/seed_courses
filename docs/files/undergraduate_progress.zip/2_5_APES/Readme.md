> 存放作業2-5檔案紀錄

### 講解重點

- 概念講解及推薦學習資源
  https://rpsychologist.com/
- 示範己學的t檢定效果量計算 8.3.1 ~ 8.3.4
- 示範pwr套件的函式 8.3.5 ~ 8.3.7

### 作業

- 依照PsyteachR ch8指引，編輯GUID_PracticeSkills_Ch8.Rmd